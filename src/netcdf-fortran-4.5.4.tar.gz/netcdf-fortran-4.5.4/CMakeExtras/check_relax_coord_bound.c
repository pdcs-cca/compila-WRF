#include <netcdf_meta.h>
#if !defined(NC_RELAX_COORD_BOUND) || NC_RELAX_COORD_BOUND == 0
      choke me
#endif
int main() {return 0;}

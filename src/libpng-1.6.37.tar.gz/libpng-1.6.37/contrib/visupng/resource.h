//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by VisualPng.rc
//
#define IDM_FILE_OPEN                   40001
#define IDM_FILE_SAVE                   40002
#define IDM_FILE_NEXT                   40003
#define IDM_FILE_PREVIOUS               40004
#define IDM_FILE_EXIT                   40005
#define IDM_OPTIONS_BACKGROUND          40006
#define IDM_OPTIONS_STRETCH             40007
#define IDM_HELP_ABOUT                  40008

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        113
#define _APS_NEXT_COMMAND_VALUE         40009
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
